import 'package:flutter/material.dart';
import '../models/data_models.dart';
import '../services/notification_service.dart'; // Import Service

class AppState extends ChangeNotifier {
  final NotificationService _notificationService = NotificationService(); // Engine Instance

  List<Category> categories = [
    Category(id: '1', name: 'Salah', icon: Icons.mosque, color: const Color(0xFF1ABC9C)),
    Category(id: '2', name: 'Quran', icon: Icons.menu_book_rounded, color: const Color(0xFF3498DB)),
    Category(id: '3', name: 'Sleep', icon: Icons.bedtime_rounded, color: const Color(0xFF9B59B6)),
    Category(id: '4', name: 'Sports', icon: Icons.directions_run_rounded, color: const Color(0xFFE67E22)),
  ];

  Map<String, List<Reminder>> categoryReminders = {};

  AppState() {
    _notificationService.init(); // Start engine when app starts
  }

  void addCategory(String name) {
    categories.add(Category(
      id: DateTime.now().toString(),
      name: name,
      icon: Icons.category_rounded,
      color: Colors.indigo,
    ));
    notifyListeners();
  }

  void removeCategory(String id) {
    categories.removeWhere((cat) => cat.id == id);
    notifyListeners();
  }

  // --- MODIFIED ADD REMINDER ---
  void addReminder(String categoryId, Reminder reminder) {
    if (!categoryReminders.containsKey(categoryId)) {
      categoryReminders[categoryId] = [];
    }
    categoryReminders[categoryId]!.add(reminder);

    // Schedule Notification
    if (reminder.isActive) {
      _notificationService.scheduleAlarm(
        id: reminder.id.hashCode, // Unique ID for notification
        title: "Routine Reminder",
        body: "Time for your task!",
        time: reminder.time,
      );
    }

    notifyListeners();
  }

  // --- MODIFIED UPDATE REMINDER ---
  void updateReminder(String categoryId, Reminder updatedReminder) {
    final list = categoryReminders[categoryId];
    if (list != null) {
      final index = list.indexWhere((r) => r.id == updatedReminder.id);
      if (index != -1) {
        list[index] = updatedReminder;

        // Cancel old alarm and set new one
        _notificationService.cancelAlarm(updatedReminder.id.hashCode);
        if (updatedReminder.isActive) {
          _notificationService.scheduleAlarm(
            id: updatedReminder.id.hashCode,
            title: "Routine Reminder",
            body: "Time for your task!",
            time: updatedReminder.time,
          );
        }

        notifyListeners();
      }
    }
  }

  // --- MODIFIED DELETE REMINDER ---
  void deleteReminder(String categoryId, String reminderId) {
    final list = categoryReminders[categoryId];
    if (list != null) {
      list.removeWhere((r) => r.id == reminderId);
      // Cancel Notification
      _notificationService.cancelAlarm(reminderId.hashCode);
      notifyListeners();
    }
  }
}