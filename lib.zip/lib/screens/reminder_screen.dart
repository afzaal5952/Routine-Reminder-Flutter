import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/data_models.dart';
import '../providers/app_state.dart';

class ReminderScreen extends StatefulWidget {
  final Category category;
  const ReminderScreen({super.key, required this.category});

  @override
  State<ReminderScreen> createState() => _ReminderScreenState();
}

class _ReminderScreenState extends State<ReminderScreen> {

  void _showAlarmSheet({Reminder? existingReminder}) {
    TimeOfDay selectedTime = existingReminder?.time ?? TimeOfDay.now();
    bool isFavorite = existingReminder?.isFavorite ?? false;
    List<bool> days = existingReminder != null
        ? List.from(existingReminder.repeatDays)
        : List.filled(7, false);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.75,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(width: 50, height: 5, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(10))),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(existingReminder == null ? "New Alarm" : "Edit Alarm",
                          style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold)
                      ),
                      if (existingReminder != null)
                        IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.red),
                          onPressed: () {
                            context.read<AppState>().deleteReminder(widget.category.id, existingReminder.id);
                            Navigator.pop(context);
                          },
                        )
                    ],
                  ),
                  const SizedBox(height: 30),

                  // Big Time Picker
                  InkWell(
                    onTap: () async {
                      final picked = await showTimePicker(context: context, initialTime: selectedTime);
                      if (picked != null) setSheetState(() => selectedTime = picked);
                    },
                    child: Center(
                      child: Text(
                        selectedTime.format(context),
                        style: GoogleFonts.poppins(fontSize: 60, fontWeight: FontWeight.bold, color: widget.category.color),
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),
                  Text("Repeat Days", style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 15),

                  // CUSTOM DAY SELECTOR
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: List.generate(7, (index) {
                      final dayLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
                      return InkWell(
                        onTap: () {
                          setSheetState(() => days[index] = !days[index]);
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                              color: days[index] ? widget.category.color : Colors.grey.shade100,
                              shape: BoxShape.circle,
                              border: Border.all(color: days[index] ? Colors.transparent : Colors.grey.shade300)
                          ),
                          child: Center(
                            child: Text(dayLabels[index],
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: days[index] ? Colors.white : Colors.black54
                                )
                            ),
                          ),
                        ),
                      );
                    }),
                  ),

                  const SizedBox(height: 30),

                  Container(
                    decoration: BoxDecoration(color: Colors.grey.shade50, borderRadius: BorderRadius.circular(15)),
                    child: CheckboxListTile(
                      activeColor: widget.category.color,
                      title: Text("Important / Favorite", style: GoogleFonts.poppins()),
                      value: isFavorite,
                      onChanged: (val) => setSheetState(() => isFavorite = val!),
                    ),
                  ),

                  const Spacer(),

                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: widget.category.color,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                        elevation: 5,
                      ),
                      onPressed: () {
                        final updated = Reminder(
                          id: existingReminder?.id ?? DateTime.now().toString(),
                          time: selectedTime,
                          repeatDays: days,
                          isFavorite: isFavorite,
                          isActive: true, // New alarms are active by default
                        );

                        if (existingReminder == null) {
                          context.read<AppState>().addReminder(widget.category.id, updated);
                        } else {
                          // Keep the existing active status if editing, or reset to true?
                          // Usually, editing implies you want it active, but let's reset to true.
                          context.read<AppState>().updateReminder(widget.category.id, updated);
                        }
                        Navigator.pop(context);
                      },
                      child: Text("Save Alarm", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white)),
                    ),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    var appState = context.watch<AppState>();
    List<Reminder> reminders = appState.categoryReminders[widget.category.id] ?? [];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(widget.category.name, style: GoogleFonts.poppins(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: widget.category.color,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text("New Alarm", style: TextStyle(color: Colors.white)),
        onPressed: () => _showAlarmSheet(existingReminder: null),
      ),

      body: reminders.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.alarm_off, size: 80, color: Colors.grey.shade300),
            const SizedBox(height: 10),
            Text("No alarms yet", style: GoogleFonts.poppins(color: Colors.grey)),
          ],
        ),
      )
          : ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: reminders.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (ctx, index) {
          final alarm = reminders[index];
          return InkWell(
            onTap: () => _showAlarmSheet(existingReminder: alarm),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                // Change color slightly if inactive
                color: alarm.isActive ? Colors.white : Colors.grey.shade100,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.grey.shade200),
                boxShadow: alarm.isActive
                    ? [BoxShadow(color: Colors.grey.shade200, blurRadius: 10, offset: const Offset(0, 5))]
                    : [],
              ),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          alarm.time.format(context),
                          style: GoogleFonts.poppins(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              // Dim the text if inactive
                              color: alarm.isActive ? Colors.black87 : Colors.grey
                          )
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          _buildDayDot(alarm.repeatDays[0], "M", alarm.isActive),
                          _buildDayDot(alarm.repeatDays[1], "T", alarm.isActive),
                          _buildDayDot(alarm.repeatDays[2], "W", alarm.isActive),
                          _buildDayDot(alarm.repeatDays[3], "T", alarm.isActive),
                          _buildDayDot(alarm.repeatDays[4], "F", alarm.isActive),
                          _buildDayDot(alarm.repeatDays[5], "S", alarm.isActive),
                          _buildDayDot(alarm.repeatDays[6], "S", alarm.isActive),
                        ],
                      )
                    ],
                  ),
                  const Spacer(),

                  // --- FUNCTIONAL SWITCH ---
                  Switch(
                    value: alarm.isActive,
                    activeColor: widget.category.color,
                    onChanged: (bool value) {
                      // Create a copy of the alarm with the new 'isActive' status
                      final updatedAlarm = Reminder(
                        id: alarm.id,
                        time: alarm.time,
                        repeatDays: alarm.repeatDays,
                        isFavorite: alarm.isFavorite,
                        isActive: value, // New value
                      );
                      // Update State
                      context.read<AppState>().updateReminder(widget.category.id, updatedAlarm);
                    },
                  ),
                  // -------------------------
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDayDot(bool isSelected, String label, bool isAlarmActive) {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: Text(label,
          style: TextStyle(
            // If alarm is OFF, all dots are grey. If ON, selected dots are colored.
              color: (isAlarmActive && isSelected) ? widget.category.color : Colors.grey.shade300,
              fontWeight: FontWeight.bold,
              fontSize: 12
          )
      ),
    );
  }
}