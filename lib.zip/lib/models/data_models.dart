import 'package:flutter/material.dart';

class Reminder {
  final String id;
  final TimeOfDay time;
  final bool isFavorite;
  final List<bool> repeatDays;
  final bool isActive; // <--- NEW FIELD

  Reminder({
    required this.id,
    required this.time,
    this.isFavorite = false,
    this.isActive = true, // <--- Default to ON
    List<bool>? repeatDays,
  }) : repeatDays = repeatDays ?? List.filled(7, false);
}

class Category {
  final String id;
  final String name;
  final IconData icon;
  final Color color;

  Category({
    required this.id,
    required this.name,
    required this.icon,
    this.color = Colors.teal,
  });
}